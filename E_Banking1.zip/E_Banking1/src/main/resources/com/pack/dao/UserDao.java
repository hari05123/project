package com.pack.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.pack.model.User;

public class UserDao {
	@Autowired
	private	 SessionFactory sessionFactory;
	public int verify(User userBean) {
		// TODO Auto-generated method stub
		
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		String hql="Select password from loginTable where username="+userBean.getUname();
		 Query query = session.createQuery(hql);
		 List<String> s=query.getResultList();
		 int k=0;
		 for(String u:s){
			 if(u==userBean.getPwd())
				 k=1;
		 }
		 
		 tx.commit();
		 return k;
		
	}

}
