package com.pack.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.pack.dao.UserDao;
import com.pack.model.User;

public class UserService {
	
	@Autowired
	private UserDao userDAO;

	public int verify(User userBean) {
		// TODO Auto-generated method stub
		int k=userDAO.verify(userBean);
		return k;
	}

}
