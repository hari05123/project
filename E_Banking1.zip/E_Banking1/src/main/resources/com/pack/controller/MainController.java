package com.pack.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.pack.model.User;
import com.pack.service.UserService;




@Controller

public class MainController {
	@Autowired
	private UserService userService;
	
	@RequestMapping("toAdd")
	public String add(Model m)
	{
		
		m.addAttribute("userBean", new User());
		return "login";
	}
	
	@RequestMapping(value="/login", method = RequestMethod.POST)


	public String saveUser(@Valid @ModelAttribute("userBean")User userBean,BindingResult result,Model m)
	{
	
	 
		//m.addAttribute("user", userBean);
  		int p=userService.verify(userBean); 
  		
	  
	  if(p>0)
  		return "home";
	  else
		  return "login";
		
	 }
	
	}
}
